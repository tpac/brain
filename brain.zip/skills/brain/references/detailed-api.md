# brain — Detailed API Reference (v5.2)

## Architecture

Serverless Python module. 11 mixin modules assembled by `brain.py`. No HTTP server.
DB resolved automatically by hooks via `resolve-brain-db.sh`.

## Node Types (37 types, schema v16)

| Category | Types | Decay |
|----------|-------|-------|
| **Core** | decision, rule | Never (locked) |
| **Core** | concept | 7 days |
| **Core** | task | 2 days |
| **Core** | context | 1 day |
| **Core** | person, project, object | 30 days |
| **Core** | file | 7 days |
| **Core** | intuition | 12 hours |
| **Core** | thought | 3 hours |
| **Core** | procedure | Never |
| **Engineering** | purpose, mechanism, impact, constraint, convention, lesson, vocabulary | Varies (constraint/lesson: never) |
| **Cognitive** | mental_model, reasoning_trace, uncertainty, correction, validation | Varies |
| **Evolution** | tension, hypothesis, pattern, catalyst, aspiration | Varies (720-2160h) |
| **Self-reflection** | performance, failure_mode, capability, interaction, meta_learning | Varies |
| **Code cognition** | fn_reasoning, param_influence, code_concept, arch_constraint, causal_chain, bug_lesson, comment_anchor | Varies |

### Critical flag (v5.2)
Any node can be marked `critical=1` via operator approval. Critical nodes:
- Get 3x recall boost in both `recall()` and `recall_with_embeddings()`
- Have lowered similarity threshold (0.20 vs normal)
- Always appear at TOP of `context_boot()` output
- Are surfaced by `safety_check()` when destructive commands detected

## Scoring Formula (v5.2)

**Combined score blend:**
- 35% relevance (keyword + TF-IDF + embeddings)
- 30% recency (time-banded)
- 25% emotion (intensity 0-1)
- 10% frequency (access count)

**Modifiers applied to relevance:**
- Hub dampening: nodes with 40+ connections get reduced
- Type dampening: project/person nodes × 0.5
- Intent boost: query intent → type-specific multipliers
- Critical boost: critical=1 nodes × 3.0
- Confidence weighting: node confidence affects final score

**Locked nodes:** Skip decay entirely. Relevance weight increased.

**Ebbinghaus retention:** `2^(-hours / half_life)` with time-dilation for personal/fluid nodes.

## Recency Bands

| Hours ago | Score |
|-----------|-------|
| < 1h | 1.0 |
| < 6h | 0.9 |
| < 24h | 0.75 |
| < 3 days | 0.5 |
| < 1 week | 0.3 |
| < 1 month | 0.15 |
| older | 0.05 |

## Recall Pipeline

1. **Step 0.5**: Vocabulary expansion — `_expand_query_with_vocabulary()` resolves operator terms
2. **Step 1a**: Keyword search + embedding scan (if available)
3. **Step 1b**: Direct keyword match strength per seed
4. **Step 2**: Spreading activation (3 hops, decay 0.5^hop)
5. **Step 3**: TF-IDF cosine similarity (batch scoring)
6. **Step 4**: Combined scoring with all modifiers
7. **Step 5**: Intent detection → type boosting
8. **Step 6**: Critical node boost
9. **Step 7**: Ebbinghaus retention decay
10. **Step 8**: Threshold filtering (0.05 normal, 0.20 for critical)

## Intent Detection

| Intent | Trigger patterns | Boosted types |
|--------|-----------------|---------------|
| decision_lookup | "what did we decide", "decision about" | decision, rule, lesson, correction |
| reasoning_chain | "why did we", "reason for" | decision, mechanism, reasoning_trace |
| state_query | "what's the current", "status of" | context, project, task, object |
| temporal | "when did", "last week", "recently" | decision, context |
| correction_lookup | "what mistake", "lessons learned" | decision, correction, lesson |
| how_to | "how do", "best way" | rule, mechanism, convention, constraint |
| list_query | "list all", "show me all" | rule, decision, object |

## Edge Types

| Type | Weight | Decays | Purpose |
|------|--------|--------|---------|
| reasoning_step | 0.9 | Never | Steps in reasoning chain |
| produced | 0.85 | Never | Chain → decision link |
| corrected_by | 0.85 | Never | Correction events |
| exemplifies | 0.8 | 30d half-life | Rule → example |
| part_of | 0.7 | Never | Structural hierarchy |
| depends_on | 0.7 | Never | Dependency |
| related | 0.5 | 14d half-life | General association |
| co_accessed | 0.3 | 7d half-life | Hebbian co-recall |
| emergent_bridge | 0.15 | 3d half-life | Auto-discovered bridge |

## Confidence System

- Each node has `confidence` (0.1-1.0), auto-set by type
- Defaults: rule=0.85, decision=0.80, hypothesis=0.50, intuition=0.40, thought=0.35
- At session boundaries: emotional cooling, temporal-external decay, silent validation boost
- `record_validation(node_id)` increases confidence
- Corrections decrease target confidence (× 0.7)

## Signal Queue (replaces consciousness signals)

Signals flow through a priority queue with budget-aware assembly. 4 producers:

- **reminders**: Due/overdue reminders. PREEMPT after 24h overdue.
- **encoding_gap**: Long session with no remember() calls.
- **vocabulary_gap**: Operator terms with no mapping.
- **system_health**: Hook errors, brain errors, rule conflicts. PREEMPT for critical errors.

Tools: `dismiss_signal(signal_id)`, `queue_state()`
- **session_health**: Overall health scoring (gaps + healthy dimensions)
- **density_shift**: Sudden change in encoding rate
- **emotional_trajectory**: Trending emotion across session
- **novelty**: Concepts created in last 2 hours

## Destructive Pattern Detection (v5.2)

`safety_check(command)` matches against:
- `rm -rf`, `rm --force`, `rmdir`
- `git reset --hard`, `git clean -fd`, `git checkout --`
- `git worktree remove`, `git push --force`
- `DROP TABLE`, `DELETE FROM`, `TRUNCATE`
- `xargs rm`

When matched: recalls critical nodes, returns risk level (high/medium/low).

## Database Schema (v16)

**Main tables:** nodes, edges, access_log, brain_meta, summaries, version_history, emotion_calibration, dream_log, node_metadata, node_embeddings, reasoning_chains, reasoning_steps, session_syntheses, correction_traces, bridge_proposals, staged_learnings, project_maps, procedures

**Key node columns:** id, type, title, content, keywords, activation, stability, access_count, locked, archived, critical, recency_score, emotion, emotion_label, confidence, personal, personal_context, project, last_accessed, created_at, updated_at

**Logs DB (brain_logs.db):** recall_log, miss_log, eval_snapshots, tuning_log, dream_log, curiosity_log, health_log, staged_learnings, error_log

## Environment Variables

| Variable | Purpose |
|----------|---------|
| BRAIN_DB_DIR | Directory containing brain.db |
| BRAIN_SERVER_DIR | Path to servers/brain.py |
| BRAIN_PROJECT | Default project name |
| BRAIN_USER | Default user name |
